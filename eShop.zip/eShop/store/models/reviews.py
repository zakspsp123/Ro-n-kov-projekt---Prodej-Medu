from django.db import models
from django.contrib.auth.models import User
from .product import Products
from .customer import Customer
from django.utils.translation import gettext_lazy as _

class Review(models.Model):
    RATING_CHOICES = (
        (1, _('1 hvězdička')),
        (2, _('2 hvězdičky')),
        (3, _('3 hvězdičky')),
        (4, _('4 hvězdičky')),
        (5, _('5 hvězdiček')),
    )
    rating = models.IntegerField(choices=RATING_CHOICES, verbose_name=_('Hodnocení'))
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, default=1, verbose_name=_('Zákazník'))
    comment = models.TextField(verbose_name=_('Komentář'))
    product = models.ForeignKey(Products, on_delete=models.CASCADE, verbose_name=_('Produkt'))

    class Meta:
        verbose_name = _('Recenze')
        verbose_name_plural = _('Recenze')

    def __str__(self):
        return f'Recenze č.{self.id} - {self.product}'

