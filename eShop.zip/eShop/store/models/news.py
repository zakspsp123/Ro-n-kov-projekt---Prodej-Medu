from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

class News(models.Model):
    title = models.CharField(max_length=100, verbose_name=_('Titulek'))
    content = models.TextField(verbose_name=_('Obsah'))
    created_at = models.DateTimeField(default=timezone.now, verbose_name=_('Datum vytvoření'))

    class Meta:
        verbose_name = _('Zpráva')
        verbose_name_plural = _('Zprávy')

    def __str__(self):
        return self.title