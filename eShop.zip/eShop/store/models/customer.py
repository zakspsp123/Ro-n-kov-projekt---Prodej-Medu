from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _

class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name=_('Uživatel'), default=None, null=True)
    first_name = models.CharField(max_length=50, verbose_name=_('Jméno'))
    last_name = models.CharField(max_length=50, verbose_name=_('Příjmení'))
    phone = models.CharField(max_length=10, verbose_name=_('Telefon'))
    email = models.EmailField(verbose_name=_('Email'))
    password = models.CharField(max_length=100, verbose_name=_('Heslo'))

    #to save the data
    def register(self):
        self.save()


    @staticmethod
    def get_customer_by_email(email):
        try:
            return Customer.objects.get(email=email)
        except Customer.DoesNotExist:
            return None

    def isExists(self):
        return Customer.objects.filter(email=self.email).exists()

    class Meta:
        verbose_name = _('Zákazník')
        verbose_name_plural = _('Zákazníci')   

    def __str__(self):
        return f'{self.first_name} {self.last_name}'