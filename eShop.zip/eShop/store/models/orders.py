from django.db import models
from .product import Products
from .customer import Customer
from django.utils.translation import gettext_lazy as _
import datetime


class Order(models.Model):
    product = models.ForeignKey(Products, on_delete=models.CASCADE, verbose_name=_('Produkt'))
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, verbose_name=_('Zákazník'))
    quantity = models.IntegerField(default=1, verbose_name=_('Množství'))
    price = models.IntegerField(verbose_name=_('Cena'))
    address = models.CharField(max_length=50, default='', blank=True, verbose_name=_('Adresa'))
    phone = models.CharField(max_length=50, default='', blank=True, verbose_name=_('Telefon'))
    date = models.DateField(auto_now_add=True, verbose_name=_('Datum'))
    status = models.BooleanField(default=False, verbose_name=_('Vyřízeno'))

    def place_order(self):
        self.save()

    @staticmethod
    def get_orders_by_customer(customer_id):
        return Order.objects.filter(customer=customer_id).order_by('-date')

    def __str__(self):
        return f'Objednávka č.{self.id} - {self.product} - {self.customer}'

    class Meta:
        verbose_name = _('Objednávka')
        verbose_name_plural = _('Objednávky')

