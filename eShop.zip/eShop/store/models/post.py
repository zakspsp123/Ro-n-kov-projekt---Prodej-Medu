from django.db import models
from django.utils.translation import gettext_lazy as _

class Post(models.Model):
    title = models.CharField(max_length=100, verbose_name=_('Titulek'))
    content = models.TextField(verbose_name=_('Obsah'))
    image = models.ImageField(upload_to='uploads/blog/', null=True, blank=True, verbose_name=_('Obrázek'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('Datum vytvoření'))

    class Meta:
        verbose_name = _('Blogy')
        verbose_name_plural = _('Blogy')

    def __str__(self):
        return f'Blog č.{self.id} - {self.title}'