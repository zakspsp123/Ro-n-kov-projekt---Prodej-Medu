from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from store.models.customer import Customer
from django.views import View

class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email
        }
        error_message = None

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password)

        error_message = self.validateCustomer(customer)

        if not error_message:
            user = User(username=email, email=email)
            user.set_password(password)

            try:
                user.save()
            except Exception as e:
                error_message = str(e)
                data = {
                    'error': error_message,
                    'values': value
                }
                return render(request, 'signup.html', data)
           
            customer.user = user
            customer.password = make_password(password)
            customer.register()
            return redirect('homepage')
        else:           
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)


    def validateCustomer(self, customer):
        error_message = None
        if not customer.first_name:
            error_message = "Prosím, zadejte vaše jméno"
        elif len(customer.first_name) < 3:
            error_message = 'Jméno musí mít alespoň 3 charaktery'
        elif not customer.last_name:
            error_message = 'Prosím, zadejte vaše jméno'
        elif len(customer.last_name) < 2:
            error_message = 'Příjmení musí mít alespoň 2 charaktery'
        elif not customer.phone:
            error_message = 'Prosím, zadejte vaše telefonní číslo'
        elif len(customer.phone) < 10:
            error_message = 'Telefenní číslo musí být 10 charakterů dlouhé (+420...)'
        elif len(customer.password) < 5:
            error_message = 'Heslo musí mít alespoň 5 charakterů'
        elif len(customer.email) < 5:
            error_message = 'Email mít alespoň 5 charakterů'
        elif customer.isExists():
            error_message = 'Email je již registrován..'

        return error_message