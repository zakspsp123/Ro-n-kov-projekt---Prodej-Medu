from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import  check_password
from django.contrib import messages
from store.models.reviews import Review
from store.models.product import Products

def reviews(request):
    if request.method == 'POST':
        if request.user.is_authenticated:
            product_id = request.POST.get('product')
            rating = request.POST.get('rating')
            comment = request.POST.get('comment')

            customer = request.user.customer
            
            product = Products.objects.get(id=product_id)
            Review.objects.create(rating=rating, comment=comment, customer=customer, product=product)

            
            reviews = Review.objects.all()
            products = Products.get_all_products()
            return render(request, 'reviews.html', {'reviews': reviews, 'products': products})
        else:
            
            messages.error(request, 'You need to login to write a review.')
            return redirect('login')
    else:
        
        reviews = Review.objects.all()
        products = Products.get_all_products()
        return render(request, 'reviews.html', {'reviews': reviews, 'products': products})