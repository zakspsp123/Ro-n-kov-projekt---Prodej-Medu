from django.shortcuts import render
from store.models.news import News

def news_list(request):
    news_items = News.objects.all().order_by('-created_at')
    return render(request, 'news/news_list.html', {'news_items': news_items})

def news_detail(request, news_id):
    news_item = News.objects.get(pk=news_id)
    return render(request, 'news/news_detail.html', {'news_item': news_item})