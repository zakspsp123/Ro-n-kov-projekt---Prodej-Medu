# store/views/product_detail.py
from django.shortcuts import render, get_object_or_404, redirect
from store.models.product import Products

def product_detail(request, product_id):
    product = get_object_or_404(Products, id=product_id)

    if request.method == 'POST':
        product_id = request.POST.get('product')
        remove = request.POST.get('remove', False)
        cart = request.session.get('cart', {})

        if remove:
            if product_id in cart:
                if cart[product_id] <= 1:
                    del cart[product_id]
                else:
                    cart[product_id] -= 1
        else:
            cart[product_id] = cart.get(product_id, 0) + 1

        request.session['cart'] = cart
        return redirect('product_detail', product_id=product.id)

    return render(request, 'product.html', {'product': product})
