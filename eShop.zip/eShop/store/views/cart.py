from django.shortcuts import render , redirect, get_object_or_404

from django.contrib.auth.hashers import  check_password
from store.models.customer import Customer
from django.views import  View
from store.models.product import Products

class Cart(View):
    def get(self , request):
        ids = list(request.session.get('cart').keys())
        products = Products.get_products_by_id(ids)
        print(products)
        return render(request , 'cart.html' , {'products' : products} )

def add_to_cart(request, product_id):
    product = Products.get_products_by_id([product_id]).first()
    if product:
        cart = request.session.get('cart', {})
        if request.method == 'POST':
            remove = request.POST.get('remove', False)
            if remove:
                if str(product.id) in cart:
                    if cart[str(product.id)] <= 1:
                        del cart[str(product.id)]
                    else:
                        cart[str(product.id)] -= 1
            else:
                cart[str(product.id)] = cart.get(str(product.id), 0) + 1

            request.session['cart'] = cart

    return redirect('product_detail', product_id=product.id)
