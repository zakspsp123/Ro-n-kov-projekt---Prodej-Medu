from django.contrib import admin
from django.urls import path
from .views.home import Index , store
from .views.signup import Signup
from .views.login import Login , logout
from .views.cart import Cart, add_to_cart
from .views.checkout import CheckOut
from .views.orders import OrderView
from .views.reviews import reviews
from .views.post import post_list
from .views.post import post_detail
from .views.product_detail import product_detail
from .middlewares.auth import  auth_middleware


urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    path('store', store , name='store'),

    path('reviews/', reviews, name='reviews'),
    path('post_list', post_list, name='post_list'),
    path('post_detail/<int:pk>/', post_detail, name='post_detail'),

    path('signup', Signup.as_view(), name='signup'),
    path('login', Login.as_view(), name='login'),
    path('logout', logout , name='logout'),
    path('cart', auth_middleware(Cart.as_view()) , name='cart'),
    path('check-out', CheckOut.as_view() , name='checkout'),
    path('orders', auth_middleware(OrderView.as_view()), name='orders'),
    path('product/<int:product_id>/', product_detail, name='product_detail'),
    path('add_to_cart/<int:product_id>/', add_to_cart, name='add_to_cart'),

]
